<?php

echo "Please check your email inbox and verify your account..";

?>